# JMS Control

Schaltet die Multiviews von JMS Control (Multiview-Server) per Stream Deck um, zeigt Ablauf und Event-Ops und schaltet in ProPresenter den Standard-Hintergrund ein.

## Multiview

- **Aktion „Multiview: Layout zeigen“**: Multiview und Layout aus den Listen wählen.
- **Aktion „Multiview: nächstes / vorheriges Layout“**
- **Aktion „Bildschirm: Multiview zuweisen“**: einen Bildschirm am Server auf einen Multiview (oder schwarz) stellen.
- **Rückmeldung „Layout ist aktiv“**: Taste leuchtet, solange das Layout auf dem Multiview läuft.
- **Presets**: unter „JMS Control / <Multiview>“ je Layout eine fertige Taste.

## Ablauf (ChurchTools)

- **Aktionen „Ablauf: nächster Punkt“, „Ablauf: vorheriger Punkt“, „Ablauf: wieder nach Uhr“**: setzen den laufenden
  Punkt wie die Bedienung der Ablauf-Kachel. Event: „Aktuelles Event“ = das Event, das die Ablauf-Kachel zeigt
  (Kachel mit Bedienung zuerst, dann eine sichtbare Kachel), oder ein festes Event aus der Liste.
- **Aktionen „Ablauf: hochscrollen“, „Ablauf: runterscrollen“, „Ablauf: zurück zum laufenden Punkt“**: scrollen
  die Ablauf-Kacheln auf allen Monitoren (auch ohne Maus) um eine halbe Kachel; das automatische Mitscrollen
  pausiert dann 30 s wie beim Mausrad, „zurück zum laufenden Punkt“ beendet die Pause sofort. Auswahl:
  „Alle Ablauf-Kacheln“ (Standard), „Aktuelles Event“ oder ein festes Event.
- **Variablen**: `$(jms-control:agenda_current)` (laufender Punkt), `agenda_remaining` (Restzeit m:ss),
  `agenda_deviation` („+4 min“, nach Uhr „nach Plan“), `agenda_next`, `agenda_next_responsible`, `agenda_event`,
  `agenda_level` (ok/warn/bad), `agenda_manual`. Sie zeigen immer das aktuelle Event.
- **Rückmeldungen**: „Ablauf: Abweichung vom Plan in Stufe“ (grün/gelb/rot, Schwellen der Ablauf-Kachel),
  „Ablauf: Punkt von Hand gesetzt“.
- **Presets** unter „Ablauf“: Status (Punkt, Restzeit, Abweichung in Ampelfarbe), ◀ / ▶, „Nach Uhr“, „Dann“,
  ▲ hoch / ▼ runter / „zum laufenden Punkt“ (Scrollen).

## Event-Ops

- **Variablen**: `$(jms-control:ops_overall)` (OK / Prüfen / Fehler), `ops_problems` (Anzahl), `ops_first`
  (wichtigstes Problem), `ops_level` (ok/warn/error/unknown).
- **Rückmeldung „Event-Ops: Ampel zeigt“** (grün/gelb/rot/unbekannt).
- **Presets** unter „Event-Ops“: Ampel mit Anzahl, wichtigstes Problem.

## ProPresenter Ein/Aus

- **Aktion „ProPresenter: Ebene aus/ein (umschalten)“**: Ist die Ebene sichtbar, wird sie ausgeblendet
  (wie „Clear“). Ist sie aus, blendet dieselbe Taste wieder ein, was vorher lief. Ebenen: Alles, Folie
  (Text), Media (Hintergrund), Audio, Meldungen, Props, Ankündigungen, Video-Eingang.
- Wiedereinblenden: Text = zuletzt gezeigte Folie; Hintergrund = die Folie, die ihn gestartet hat (der
  Text kommt danach wieder darüber), sonst das Medium aus seiner Media-Playlist; Audio = aus seiner
  Audio-Playlist an derselben Stelle; Meldungen/Props = die vorher aktiven. Das Video beginnt dabei von vorn.
- **Rückmeldung „ProPresenter: Ebene ist sichtbar“**, Variablen `$(jms-control:pp_slide)` usw. (ein/aus).
- **Presets** unter „ProPresenter Ein/Aus“: je Ebene eine Taste (grün = sichtbar, dunkelrot = aus).

## ProPresenter

- **Aktion „ProPresenter: Standard-Hintergrund“**: legt den Standard-Hintergrund (z. B. den blauen) auf die
  Media-Ebene; der Text darüber bleibt. Welches Medium, legt der Admin in JMS Control unter
  *Einstellungen → ProPresenter → Standard-Hintergrund* fest. Ohne Einstellung meldet die Taste einen Fehler im Log.
- **Rückmeldung „ProPresenter: Standard-Hintergrund läuft“**: leuchtet blau, solange er auf der Media-Ebene sichtbar ist.
- **Variable** `$(jms-control:pp_standard_background)`: Name des Mediums.
- **Preset** unter „ProPresenter“: „Standard-Hintergrund“.

Die Verbindung meldet sich mit dem Geräteschlüssel `jms-device.key` neben dem Modul an
(festes Gerät „Companion-JMS-Control“, Steuerrechte nur für den Multiview).
